Pasta do Emagrecimento • Premium (PWA offline)

✅ O que é:
- Um mini app que roda no celular e salva seus dados (localStorage).
- Dashboard diário + Score automático + Gráfico (peso e score)
- Cronograma de doses (sextas, iniciando em 16/01/2026)
- Metas configuráveis + Relatório semanal com 1 clique
- Backup / Restore em arquivo .json

📌 Como usar (rápido):
1) Extraia o ZIP.
2) Abra index.html no computador (funciona).
3) Para instalar como APP no celular (recomendado):
   - Abra via http/https (não por arquivo file://).

✅ Android (mais fácil):
- Suba os arquivos no GitHub Pages ou Netlify
- Abra no Chrome
- Menu ⋮ → “Adicionar à tela inicial”

⚠️ Observação:
- Offline total (service worker) funciona quando está em http/https.

Diniz Almeida — Operação 110 → 94
